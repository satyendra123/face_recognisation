package org.java_websocket.enums;

/**
 * Enum which represents the states a websocket may be in
 */
public enum Role {
  CLIENT, SERVER
}