package com.timmy.websocket;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Text {

	public static void main(String[] args) throws InterruptedException{
	    /*  System.out.println("开始启动webSocket");
	      WebSocketImpl.DEBUG = false;
	      int port = 7788; // 端口随便设置，只要不跟现有端口重复就可以了
	      WebSocket s =null;
	      try {
	          s = new WebSocket(port);
	          s.start();
	        //  s.onOpen(conn, handshake);
	      } catch (UnknownHostException e1) {
	          System.out.println("启动webSocket失败！");
	          e1.printStackTrace();
	      }
	    
	      System.out.println("启动webSocket成功！");
	      System.out.println("连接数"+l);*/
	//	final WebSocket websocket=
	//
		//org.java_websocket.WebSocket conn = null;
		
	//
		//System.out.println(new W);
	      
	 }

}
