package com.timmy.service;

import com.timmy.entity.LockGroup;

public interface LockGroupService {
	
	void setLockGroup(LockGroup lockGroup);

}
