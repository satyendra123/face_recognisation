package com.timmy.controller;

public class GenerateQRcodeRecord {

}
