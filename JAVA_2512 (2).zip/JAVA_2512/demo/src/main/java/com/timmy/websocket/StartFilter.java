package com.timmy.websocket;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class StartFilter implements Filter {

	public void destroy() {

	}

	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {

	}

	public void init(FilterConfig arg0) throws ServletException {
		this.startWebsocketInstantMsg();
	}

	/**
	 * 启动即时聊天服务
	 */
	public void startWebsocketInstantMsg() {
		ApplicationContext ac = new FileSystemXmlApplicationContext("classpath:spring-mybatis.xml");
		WSServer ws = (WSServer) ac.getBean("webSocket");
//		// 启用wss连接
//		// 设置密钥库和密码
//		String keyStorePath = "D:\\apache-tomcat-vi\\apache-tomcat-9.0.62\\cert\\global.yunatt.com.pfx";
//		String keyStorePassword = "1234567";
//		SSLContext sslContext = null;
//		// 加载密钥库
//		try {
//			KeyStore keystore = KeyStore.getInstance("PKCS12");
//			FileInputStream fis = new FileInputStream(keyStorePath);
//			keystore.load(fis, keyStorePassword.toCharArray());
//			fis.close();
//			KeyManagerFactory keyManagerFactory = KeyManagerFactory
//					.getInstance(KeyManagerFactory.getDefaultAlgorithm());
//			keyManagerFactory.init(keystore, keyStorePassword.toCharArray());
//			sslContext = SSLContext.getInstance("TLS");
//			sslContext.init(keyManagerFactory.getKeyManagers(), null, null);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		ws.setWebSocketFactory(new DefaultSSLWebSocketServerFactory(sslContext));
		ws.start();
		// ws.onMessage( , message);
		// String message="{\"cmd\":\"getuserlist\",\"stn\":true}";
	}
}